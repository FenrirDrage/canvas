/* Global scroll suave */
html {
  scroll-behavior: smooth;
}

/* Secções ocupando toda a altura da janela do navegador */
.section {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  transition: transform 0.8s ease-in-out; /* Transição para o efeito de slide */
  opacity: 0;
  transform: translateY(100vh); /* Começa fora da tela */
}

/* Quando a secção estiver ativa, faz o slide para a posição correta */
.section.active {
  opacity: 1;
  transform: translateY(0); /* Move para a posição inicial */
}

/* Estilo para o canvas e as caixas de texto do jogo */
canvas {
  border: 2px solid #000;
  margin-top: 20px;
}

/* Caixa de texto para o jogo de dislexia */
#dislexiaTextbox {
  margin-top: 20px;
  text-align: center;
}

/* Botões de jogo */
button {
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  cursor: pointer;
  transition: background-color 0.3s;
}

/* Efeito hover nos botões */
button:hover {
  background-color: #0056b3;
}

/* Estilos para as setas de navegação */
.scroll-arrow {
  font-size: 2rem;
  text-decoration: none;
  color: black;
  margin-top: 20px;
}

.scroll-arrow:hover {
  color: #555;
}

/* Seta anterior, posicionada no topo */
.scroll-arrow.previous {
  position: absolute;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
}

/* Seta próxima, posicionada no fundo */
.scroll-arrow.next {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
}

/* Esconder o canvas e a caixa de texto quando o jogo não estiver ativo */
#dislexiaCanvas, #dislexiaTextbox, #discalculiaCanvas {
  display: none;
}

/* Estilo para a secção de dislexia */
.dislexia-content {
  display: flex;
  justify-content: space-around;
  align-items: center;
  flex-wrap: wrap;
  padding: 20px;
}

/* Estilo do texto da dislexia */
.dislexia-text {
  flex: 1; /* Ocupa o espaço necessário */
  padding-right: 20px;
  text-align: left;
}

/* Estilo do canvas na secção de dislexia */
.dislexia-canvas {
  flex: 1;
}

/* Responsividade para dispositivos móveis */
@media (max-width: 768px) {
  .dislexia-content {
      flex-direction: column;
      text-align: center;
  }

  .dislexia-text {
      padding-right: 0;
  }

  .scroll-arrow.previous, .scroll-arrow.next {
      position: static;
      margin-top: 10px;
  }

  canvas {
      width: 100%;
      height: auto;
  }
}
